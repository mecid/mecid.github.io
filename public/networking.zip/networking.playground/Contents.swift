import Foundation
import Combine

extension URLRequest {
    enum HttpMethod: String {
        case get = "GET"
        case post = "POST"
        case put = "PUT"
        case delete = "DELETE"
    }

    static func get(
        url: URL,
        queryItems: [URLQueryItem] = [],
        headers: [String: String] = [:]
    ) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = HttpMethod.get.rawValue
        request.allHTTPHeaderFields = headers
        return request
    }
}

extension URLRequest {
    static func feed() -> URLRequest {
        get(url: URL(string: "feed.json")!)
    }
}

typealias Networking = (URLRequest) ->
    AnyPublisher<(data: Data, response: URLResponse), Error>

extension URLSession {
    func erasedDataTaskPublisher(
        for request: URLRequest
    ) -> AnyPublisher<(data: Data, response: URLResponse), Error> {
        dataTaskPublisher(for: request)
            .mapError { $0 }
            .eraseToAnyPublisher()
    }
}

let networking: Networking = URLSession.shared.erasedDataTaskPublisher(for:)

struct Feed: Decodable {}

struct FeedService {
    let networking: Networking

    func fetchFeed() -> AnyPublisher<Feed, Error> {
        networking(.feed())
            .map { $0.data }
            .decode(type: Feed.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
}

let feedService = FeedService(networking: URLSession.shared.erasedDataTaskPublisher)
feedService.fetchFeed()

func mockNetworking(
    data: Data = .init(),
    response: URLResponse = .init()
) -> Networking {
    return { _ in
        Just((data: data, response: response))
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }
}

let mockedFeedService = FeedService(networking: mockNetworking())

func tokenRequestModifier(_ token: String) -> (URLRequest) -> URLRequest {
    return { request in
        var request = request
        request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        return request
    }
}

func compose<A, B, C>(
    _ f: @escaping (A) -> B,
    _ g: @escaping (B) -> C
) -> (A) -> C {
    return { g(f($0)) }
}

let token = UserDefaults.standard.string(forKey: "token") ?? ""
let authorizedNetworking = compose(tokenRequestModifier(token), networking)

authorizedNetworking(.feed())
